package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.YjAuditApplyH;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface YjAuditApplyHMapper extends BaseMapper<YjAuditApplyH, String> {
}