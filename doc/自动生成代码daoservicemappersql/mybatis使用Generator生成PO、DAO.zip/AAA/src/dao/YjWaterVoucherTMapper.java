package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.YjWaterVoucherT;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface YjWaterVoucherTMapper extends BaseMapper<YjWaterVoucherT, String> {
}