package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.PgMessageInfo;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface PgMessageInfoMapper extends BaseMapper<PgMessageInfo, String> {
}