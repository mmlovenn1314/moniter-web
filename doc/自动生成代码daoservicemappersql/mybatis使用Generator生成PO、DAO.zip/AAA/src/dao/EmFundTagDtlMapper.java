package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.EmFundTagDtl;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface EmFundTagDtlMapper extends BaseMapper<EmFundTagDtl, String> {
}