package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.BpPushRuleH;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface BpPushRuleHMapper extends BaseMapper<BpPushRuleH, String> {
}