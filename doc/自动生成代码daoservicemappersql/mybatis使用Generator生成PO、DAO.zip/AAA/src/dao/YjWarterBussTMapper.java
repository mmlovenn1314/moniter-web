package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.YjWarterBussT;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface YjWarterBussTMapper extends BaseMapper<YjWarterBussT, String> {
}