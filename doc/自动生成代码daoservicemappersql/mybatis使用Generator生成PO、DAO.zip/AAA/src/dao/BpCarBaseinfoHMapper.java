package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.BpCarBaseinfoH;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface BpCarBaseinfoHMapper extends BaseMapper<BpCarBaseinfoH, String> {
}