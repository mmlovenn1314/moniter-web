package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.BpPointRuleM;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface BpPointRuleMMapper extends BaseMapper<BpPointRuleM, String> {
}