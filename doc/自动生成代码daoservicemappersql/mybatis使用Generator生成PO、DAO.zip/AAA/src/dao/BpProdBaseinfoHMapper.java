package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.BpProdBaseinfoH;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface BpProdBaseinfoHMapper extends BaseMapper<BpProdBaseinfoH, String> {
}