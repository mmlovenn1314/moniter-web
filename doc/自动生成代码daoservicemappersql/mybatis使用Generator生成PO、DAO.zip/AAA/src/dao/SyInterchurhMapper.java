package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.SyInterchurh;
import entity.SyInterchurhKey;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface SyInterchurhMapper extends BaseMapper<SyInterchurh, String> {
}