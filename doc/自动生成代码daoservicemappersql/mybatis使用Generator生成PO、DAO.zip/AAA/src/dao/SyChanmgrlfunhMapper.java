package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.SyChanmgrlfunh;
import entity.SyChanmgrlfunhKey;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface SyChanmgrlfunhMapper extends BaseMapper<SyChanmgrlfunh, String> {
}