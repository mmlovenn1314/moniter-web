package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.SyChanmgfunm;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface SyChanmgfunmMapper extends BaseMapper<SyChanmgfunm, String> {
}