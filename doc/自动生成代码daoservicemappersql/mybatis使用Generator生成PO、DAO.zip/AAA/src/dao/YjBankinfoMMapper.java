package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.YjBankinfoM;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface YjBankinfoMMapper extends BaseMapper<YjBankinfoM, String> {
}