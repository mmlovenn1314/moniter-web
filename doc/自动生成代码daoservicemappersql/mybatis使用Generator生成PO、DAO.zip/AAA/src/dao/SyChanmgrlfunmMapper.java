package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.SyChanmgrlfunm;
import entity.SyChanmgrlfunmKey;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface SyChanmgrlfunmMapper extends BaseMapper<SyChanmgrlfunm, String> {
}