package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.SyFunduserm;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface SyFundusermMapper extends BaseMapper<SyFunduserm, String> {
}