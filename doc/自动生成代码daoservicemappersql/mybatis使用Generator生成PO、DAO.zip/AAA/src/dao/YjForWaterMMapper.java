package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.YjForWaterM;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface YjForWaterMMapper extends BaseMapper<YjForWaterM, String> {
}