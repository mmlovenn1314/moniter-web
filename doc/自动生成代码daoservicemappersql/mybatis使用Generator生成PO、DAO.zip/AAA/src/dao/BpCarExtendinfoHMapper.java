package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.BpCarExtendinfoH;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface BpCarExtendinfoHMapper extends BaseMapper<BpCarExtendinfoH, String> {
}