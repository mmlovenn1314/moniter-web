package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.BpCustomerprodRulematchM;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface BpCustomerprodRulematchMMapper extends BaseMapper<BpCustomerprodRulematchM, String> {
}