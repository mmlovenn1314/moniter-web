package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.YjVoucherWater;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface YjVoucherWaterMapper extends BaseMapper<YjVoucherWater, String> {
}