package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.YjSummaryH;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface YjSummaryHMapper extends BaseMapper<YjSummaryH, String> {
}