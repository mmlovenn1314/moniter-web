package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.SyChanmgtokenm;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface SyChanmgtokenmMapper extends BaseMapper<SyChanmgtokenm, String> {
}