package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.YjCashapplyM;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface YjCashapplyMMapper extends BaseMapper<YjCashapplyM, String> {
}