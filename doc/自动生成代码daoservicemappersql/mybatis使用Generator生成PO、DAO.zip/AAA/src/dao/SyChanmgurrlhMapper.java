package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.SyChanmgurrlh;
import entity.SyChanmgurrlhKey;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface SyChanmgurrlhMapper extends BaseMapper<SyChanmgurrlh, String> {
}