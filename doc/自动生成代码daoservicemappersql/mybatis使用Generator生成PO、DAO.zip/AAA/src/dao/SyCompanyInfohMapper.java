package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.SyCompanyInfoh;
import entity.SyCompanyInfohKey;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface SyCompanyInfohMapper extends BaseMapper<SyCompanyInfoh, String> {
}