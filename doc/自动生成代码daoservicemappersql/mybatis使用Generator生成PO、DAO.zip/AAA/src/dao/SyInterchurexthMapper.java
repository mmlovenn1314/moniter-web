package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.SyInterchurexth;
import entity.SyInterchurexthKey;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface SyInterchurexthMapper extends BaseMapper<SyInterchurexth, String> {
}