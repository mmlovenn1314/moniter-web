package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.BpCustInfoH;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface BpCustInfoHMapper extends BaseMapper<BpCustInfoH, String> {
}