package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.SyChanmguserh;
import entity.SyChanmguserhKey;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface SyChanmguserhMapper extends BaseMapper<SyChanmguserh, String> {
}