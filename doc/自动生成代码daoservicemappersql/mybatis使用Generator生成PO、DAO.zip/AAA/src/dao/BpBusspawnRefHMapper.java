package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.BpBusspawnRefH;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface BpBusspawnRefHMapper extends BaseMapper<BpBusspawnRefH, String> {
}