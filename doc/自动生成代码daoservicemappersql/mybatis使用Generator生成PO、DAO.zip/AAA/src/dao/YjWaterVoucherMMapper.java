package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.YjWaterVoucherM;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface YjWaterVoucherMMapper extends BaseMapper<YjWaterVoucherM, String> {
}