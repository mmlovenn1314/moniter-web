package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.EmChurTagDtl;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface EmChurTagDtlMapper extends BaseMapper<EmChurTagDtl, String> {
}