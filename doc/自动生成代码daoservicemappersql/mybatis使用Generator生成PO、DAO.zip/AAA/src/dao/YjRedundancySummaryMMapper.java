package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.YjRedundancySummaryM;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface YjRedundancySummaryMMapper extends BaseMapper<YjRedundancySummaryM, String> {
}