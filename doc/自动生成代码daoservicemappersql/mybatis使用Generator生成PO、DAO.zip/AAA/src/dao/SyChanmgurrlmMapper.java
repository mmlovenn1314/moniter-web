package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.SyChanmgurrlm;
import entity.SyChanmgurrlmKey;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface SyChanmgurrlmMapper extends BaseMapper<SyChanmgurrlm, String> {
}