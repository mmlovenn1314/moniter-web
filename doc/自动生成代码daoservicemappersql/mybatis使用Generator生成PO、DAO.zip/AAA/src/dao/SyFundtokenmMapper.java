package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.SyFundtokenm;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface SyFundtokenmMapper extends BaseMapper<SyFundtokenm, String> {
}