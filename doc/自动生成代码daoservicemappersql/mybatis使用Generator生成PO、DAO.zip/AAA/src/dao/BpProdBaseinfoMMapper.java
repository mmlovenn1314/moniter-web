package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.BpProdBaseinfoM;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface BpProdBaseinfoMMapper extends BaseMapper<BpProdBaseinfoM, String> {
}