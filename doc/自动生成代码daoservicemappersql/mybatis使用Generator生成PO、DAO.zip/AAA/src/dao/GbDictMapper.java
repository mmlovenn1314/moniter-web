package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.GbDict;
import entity.GbDictKey;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface GbDictMapper extends BaseMapper<GbDict, String> {
}