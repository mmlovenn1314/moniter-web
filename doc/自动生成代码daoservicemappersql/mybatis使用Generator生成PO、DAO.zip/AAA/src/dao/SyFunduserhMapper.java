package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.SyFunduserh;
import entity.SyFunduserhKey;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface SyFunduserhMapper extends BaseMapper<SyFunduserh, String> {
}