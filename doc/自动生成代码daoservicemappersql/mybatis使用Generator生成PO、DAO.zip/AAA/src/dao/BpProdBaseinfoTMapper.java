package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.BpProdBaseinfoT;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface BpProdBaseinfoTMapper extends BaseMapper<BpProdBaseinfoT, String> {
}