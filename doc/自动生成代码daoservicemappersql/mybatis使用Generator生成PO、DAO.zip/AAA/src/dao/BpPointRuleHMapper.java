package dao;

import com.petecat.interchan.core.mapper.BaseMapper;
import entity.BpPointRuleH;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface BpPointRuleHMapper extends BaseMapper<BpPointRuleH, String> {
}