package entity;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class SyChanmgurrlm extends SyChanmgurrlmKey implements Serializable {
    /**
     * ����ʱ��
     */
    private Date operateTmie;

    /**
     * ������
     */
    private String operateUser;

    /**
     * sy_chanmgurrlm
     */
    private static final long serialVersionUID = 1L;
}