package entity;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class SyChanmgrlfunm extends SyChanmgrlfunmKey implements Serializable {
    /**
     * ����ʱ��
     */
    private Date operateTmie;

    /**
     * ������
     */
    private String operateUser;

    /**
     * sy_chanmgrlfunm
     */
    private static final long serialVersionUID = 1L;
}