package entity;

import com.petecat.interchan.core.entity.BaseEntity;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class SyChanmgrolem extends BaseEntity implements Serializable {
    /**
     * ��ɫ����
     */
    private String roleid;

    /**
     * ��ɫ����
     */
    private String roledesc;

    /**
     * ��˱��[0 ��Ч 1 ��Ч]
     */
    private String markflag;

    /**
     * ������
     */
    private String operateUser;

    /**
     * ����ʱ��
     */
    private Date operateTmie;

    /**
     * sy_chanmgrolem
     */
    private static final long serialVersionUID = 1L;
}