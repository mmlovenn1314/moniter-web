package entity;

import com.petecat.interchan.core.entity.BaseEntity;
import lombok.Data;

@Data
public class SyChanmgrlfunhKey extends BaseEntity {
    /**
     * Ȩ��ID
     */
    private String funid;

    /**
     * ��ʷ���к�
     */
    private String seqno;

    /**
     * �û�ID
     */
    private String userid;

    public SyChanmgrlfunhKey(String funid, String seqno, String userid) {
        this.funid = funid;
        this.seqno = seqno;
        this.userid = userid;
    }

    /**
     * Ȩ��ID
     * @return FUNID Ȩ��ID
     */
    public String getFunid() {
        return funid;
    }

    /**
     * ��ʷ���к�
     * @return SEQNO ��ʷ���к�
     */
    public String getSeqno() {
        return seqno;
    }

    /**
     * �û�ID
     * @return USERID �û�ID
     */
    public String getUserid() {
        return userid;
    }
}