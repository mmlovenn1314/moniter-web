package entity;

import com.petecat.interchan.core.entity.BaseEntity;
import lombok.Data;

@Data
public class SyChanmguserhKey extends BaseEntity {
    /**
     * ��ʷ���к�
     */
    private String seqno;

    /**
     * �û�Ψһ���
     */
    private String userid;

    public SyChanmguserhKey(String seqno, String userid) {
        this.seqno = seqno;
        this.userid = userid;
    }

    /**
     * ��ʷ���к�
     * @return SEQNO ��ʷ���к�
     */
    public String getSeqno() {
        return seqno;
    }

    /**
     * �û�Ψһ���
     * @return USERID �û�Ψһ���
     */
    public String getUserid() {
        return userid;
    }
}