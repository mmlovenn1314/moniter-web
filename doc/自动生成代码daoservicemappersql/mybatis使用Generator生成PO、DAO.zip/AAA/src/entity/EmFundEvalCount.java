package entity;

import com.petecat.interchan.core.entity.BaseEntity;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class EmFundEvalCount extends BaseEntity implements Serializable {
    /**
     * �ʷ�Ψһ��ʶ
     */
    private String companyId;

    /**
     * �������ܷ�ֵ
     */
    private Integer evalScore;

    /**
     * ״̬
     */
    private String status;

    /**
     * ��������
     */
    private String lastModifyUser;

    /**
     * ������ʱ��
     */
    private Date lastModifyTime;

    /**
     * em_fund_eval_count
     */
    private static final long serialVersionUID = 1L;
}