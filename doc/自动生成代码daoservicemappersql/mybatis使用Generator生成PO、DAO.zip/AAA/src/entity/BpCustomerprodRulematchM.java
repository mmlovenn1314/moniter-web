package entity;

import com.petecat.interchan.core.entity.BaseEntity;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

@Data
public class BpCustomerprodRulematchM extends BaseEntity implements Serializable {
    /**
     * ͨ�ù���id
     */
    private String customerprodRulematch;

    /**
     * ��Ʒ����
     */
    private String prodId;

    /**
     * �ֶ�����
     */
    private String fieldName;

    /**
     * �ֶ�����
     */
    private String fieldDesc;

    /**
     * Ȩ��ֵ
     */
    private BigDecimal weightValue;

    /**
     * ������
     */
    private String operateUser;

    /**
     * ����ʱ��
     */
    private Date operateTmie;

    /**
     * bp_customerprod_rulematch_m
     */
    private static final long serialVersionUID = 1L;
}