package entity;

import com.petecat.interchan.core.entity.BaseEntity;
import lombok.Data;

@Data
public class SyChanmgurrlhKey extends BaseEntity {
    /**
     * ��ɫID
     */
    private String roleid;

    /**
     * ��ʷ����ֵ
     */
    private String seqno;

    /**
     * �û�ID
     */
    private String userid;

    public SyChanmgurrlhKey(String roleid, String seqno, String userid) {
        this.roleid = roleid;
        this.seqno = seqno;
        this.userid = userid;
    }

    /**
     * ��ɫID
     * @return ROLEID ��ɫID
     */
    public String getRoleid() {
        return roleid;
    }

    /**
     * ��ʷ����ֵ
     * @return SEQNO ��ʷ����ֵ
     */
    public String getSeqno() {
        return seqno;
    }

    /**
     * �û�ID
     * @return USERID �û�ID
     */
    public String getUserid() {
        return userid;
    }
}