package entity;

import com.petecat.interchan.core.entity.BaseEntity;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class EmFundTagDtl extends BaseEntity implements Serializable {
    /**
     * ҵ��Ψһ��ʶ
     */
    private String applyInfoId;

    /**
     * �ʷ�Ψһ��ʶ
     */
    private String companyId;

    /**
     * ��ǩ����
     */
    private Integer tagCode;

    /**
     * ����ʱ��
     */
    private Date createTime;

    /**
     * em_fund_tag_dtl
     */
    private static final long serialVersionUID = 1L;
}