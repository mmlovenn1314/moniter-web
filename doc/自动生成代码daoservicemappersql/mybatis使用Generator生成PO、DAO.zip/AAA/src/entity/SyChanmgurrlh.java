package entity;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class SyChanmgurrlh extends SyChanmgurrlhKey implements Serializable {
    /**
     * ����ʱ��
     */
    private Date operateTmie;

    /**
     * ������
     */
    private String operateUser;

    /**
     * sy_chanmgurrlh
     */
    private static final long serialVersionUID = 1L;
}