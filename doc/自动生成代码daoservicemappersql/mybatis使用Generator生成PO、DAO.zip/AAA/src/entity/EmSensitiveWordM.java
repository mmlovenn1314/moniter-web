package entity;

import com.petecat.interchan.core.entity.BaseEntity;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class EmSensitiveWordM extends BaseEntity implements Serializable {
    /**
     * Ψһ��ʶ
     */
    private String infoId;

    /**
     * ���д�����
     */
    private String wordContent;

    /**
     * ˵����Ϣ
     */
    private String wordDesc;

    /**
     * ״̬
     */
    private String status;

    /**
     * ������
     */
    private String createUser;

    /**
     * ����ʱ��
     */
    private Date createTime;

    /**
     * ��������
     */
    private String lastModifyUser;

    /**
     * ������ʱ��
     */
    private Date lastModifyTime;

    /**
     * �汾��
     */
    private Integer version;

    /**
     * em_sensitive_word_m
     */
    private static final long serialVersionUID = 1L;
}