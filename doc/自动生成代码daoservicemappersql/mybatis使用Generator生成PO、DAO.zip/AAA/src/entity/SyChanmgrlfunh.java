package entity;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class SyChanmgrlfunh extends SyChanmgrlfunhKey implements Serializable {
    /**
     * ����ʱ��
     */
    private Date operateTmie;

    /**
     * ������
     */
    private String operateUser;

    /**
     * sy_chanmgrlfunh
     */
    private static final long serialVersionUID = 1L;
}