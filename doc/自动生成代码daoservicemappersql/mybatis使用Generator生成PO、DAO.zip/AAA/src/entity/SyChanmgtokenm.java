package entity;

import com.petecat.interchan.core.entity.BaseEntity;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class SyChanmgtokenm extends BaseEntity implements Serializable {
    /**
     * �û�Ψһ��ʾ
     */
    private String userid;

    /**
     * tokenֵ
     */
    private String token;

    /**
     * ����ʱ��
     */
    private Date gtime;

    /**
     * ʧЧʱ��
     */
    private Date invalidtime;

    /**
     * sy_chanmgtokenm
     */
    private static final long serialVersionUID = 1L;
}