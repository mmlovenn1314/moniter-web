package entity;

import com.petecat.interchan.core.entity.BaseEntity;
import lombok.Data;

@Data
public class SyChanmgrlfunmKey extends BaseEntity {
    /**
     * Ȩ��ID
     */
    private String funid;

    /**
     * �û�ID
     */
    private String userid;

    public SyChanmgrlfunmKey(String funid, String userid) {
        this.funid = funid;
        this.userid = userid;
    }

    /**
     * Ȩ��ID
     * @return FUNID Ȩ��ID
     */
    public String getFunid() {
        return funid;
    }

    /**
     * �û�ID
     * @return USERID �û�ID
     */
    public String getUserid() {
        return userid;
    }
}