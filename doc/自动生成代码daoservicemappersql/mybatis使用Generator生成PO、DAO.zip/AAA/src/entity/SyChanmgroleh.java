package entity;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class SyChanmgroleh extends SyChanmgrolehKey implements Serializable {
    /**
     * ��ɫ����
     */
    private String roledesc;

    /**
     * ��˱��[0 ��Ч 1 ��Ч]
     */
    private String markflag;

    /**
     * ������
     */
    private String operateUser;

    /**
     * ����ʱ��
     */
    private Date operateTmie;

    /**
     * sy_chanmgroleh
     */
    private static final long serialVersionUID = 1L;
}