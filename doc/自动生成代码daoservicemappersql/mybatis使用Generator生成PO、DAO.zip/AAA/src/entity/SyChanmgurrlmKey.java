package entity;

import com.petecat.interchan.core.entity.BaseEntity;
import lombok.Data;

@Data
public class SyChanmgurrlmKey extends BaseEntity {
    /**
     * ��ɫID
     */
    private String roleid;

    /**
     * �û�ID
     */
    private String userid;

    public SyChanmgurrlmKey(String roleid, String userid) {
        this.roleid = roleid;
        this.userid = userid;
    }

    /**
     * ��ɫID
     * @return ROLEID ��ɫID
     */
    public String getRoleid() {
        return roleid;
    }

    /**
     * �û�ID
     * @return USERID �û�ID
     */
    public String getUserid() {
        return userid;
    }
}