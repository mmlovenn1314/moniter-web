package entity;

import com.petecat.interchan.core.entity.BaseEntity;
import lombok.Data;

@Data
public class SyCompanyInfohKey extends BaseEntity {
    /**
     * �ʷ�Ψһ��ʶ
     */
    private String companyId;

    /**
     * ��ʷ����ֵ
     */
    private String seqno;

    public SyCompanyInfohKey(String companyId, String seqno) {
        this.companyId = companyId;
        this.seqno = seqno;
    }

    /**
     * �ʷ�Ψһ��ʶ
     * @return COMPANY_ID �ʷ�Ψһ��ʶ
     */
    public String getCompanyId() {
        return companyId;
    }

    /**
     * ��ʷ����ֵ
     * @return SEQNO ��ʷ����ֵ
     */
    public String getSeqno() {
        return seqno;
    }
}