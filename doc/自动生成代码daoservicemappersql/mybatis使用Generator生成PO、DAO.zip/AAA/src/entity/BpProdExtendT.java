package entity;

import com.petecat.interchan.core.entity.BaseEntity;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class BpProdExtendT extends BaseEntity implements Serializable {
    /**
     * ��Ʒ����
     */
    private String prodId;

    /**
     * ������
     */
    private String propertyName;

    /**
     * ����ֵ
     */
    private String propertyValue;

    /**
     * ������
     */
    private String operateUser;

    /**
     * ����ʱ��
     */
    private Date operateTmie;

    /**
     * bp_prod_extend_t
     */
    private static final long serialVersionUID = 1L;
}