package entity;

import com.petecat.interchan.core.entity.BaseEntity;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class EmChurEvalCount extends BaseEntity implements Serializable {
    /**
     * ������Ψһ��ʶ
     */
    private String channelUserId;

    /**
     * �������ܷ�ֵ
     */
    private Integer evalScore;

    /**
     * ״̬
     */
    private String status;

    /**
     * ��������
     */
    private String lastModifyUser;

    /**
     * ������ʱ��
     */
    private Date lastModifyTime;

    /**
     * em_chur_eval_count
     */
    private static final long serialVersionUID = 1L;
}