package entity;

import com.petecat.interchan.core.entity.BaseEntity;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class EmChurTagDtl extends BaseEntity implements Serializable {
    /**
     * ҵ��Ψһ��ʶ
     */
    private String applyInfoId;

    /**
     * ������Ψһ��ʶ
     */
    private String channelUserId;

    /**
     * ��ǩ����
     */
    private Integer tagCode;

    /**
     * ����ʱ��
     */
    private Date createTime;

    /**
     * em_chur_tag_dtl
     */
    private static final long serialVersionUID = 1L;
}