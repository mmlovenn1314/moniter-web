package entity;

import com.petecat.interchan.core.entity.BaseEntity;
import lombok.Data;

@Data
public class SyInterchurexthKey extends BaseEntity {
    /**
     * �û�Ψһ��ʾ
     */
    private String channelUserId;

    /**
     * 
     */
    private String seqno;

    public SyInterchurexthKey(String channelUserId, String seqno) {
        this.channelUserId = channelUserId;
        this.seqno = seqno;
    }

    /**
     * �û�Ψһ��ʾ
     * @return CHANNEL_USER_ID �û�Ψһ��ʾ
     */
    public String getChannelUserId() {
        return channelUserId;
    }

    /**
     * 
     * @return SEQNO 
     */
    public String getSeqno() {
        return seqno;
    }
}