package entity;

import com.petecat.interchan.core.entity.BaseEntity;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

@Data
public class SyCompanyInfom extends BaseEntity implements Serializable {
    /**
     * �ʷ�Ψһ��ʶ
     */
    private String companyId;

    /**
     * ��˾����
     */
    private String companyName;

    /**
     * ��Ч״̬
     */
    private String status;

    /**
     * ע��ʱ��
     */
    private Date regTime;

    /**
     * ��Чʱ��
     */
    private Date vaildTime;

    /**
     * ����
     */
    private Integer point;

    /**
     * ��ϵ��
     */
    private String linkman;

    /**
     * ��ϵ�绰
     */
    private String linkmobile;

    /**
     * ��˾��ϸ��ַ
     */
    private String regAddr;

    /**
     * ��˾ע���ʽ�
     */
    private BigDecimal regCapital;

    /**
     * ����
     */
    private String legalPerson;

    /**
     * ����
     */
    private String email;

    /**
     * ������
     */
    private String operateUser;

    /**
     * ����ʱ��
     */
    private Date operateTmie;

    /**
     * sy_company_infom
     */
    private static final long serialVersionUID = 1L;
}